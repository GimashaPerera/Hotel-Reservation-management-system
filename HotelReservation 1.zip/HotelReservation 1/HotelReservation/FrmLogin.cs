﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HotelReservation
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmRegister frmReg = new FrmRegister();
            frmReg.Show();
            this.Hide();
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {







        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //connection
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();

            //command
            string sql = "SELECT * FROM tblRegister WHERE Username =@un AND Password=@pw ";
            SqlCommand cmd = new SqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@un", this.txtUsername.Text);
            cmd.Parameters.AddWithValue("@pw", this.txtPassword.Text);


            //access data using datareader
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read() == true)
            {
                Program.Username = txtUsername.Text; // username to dasboard welcome
               

                FrmDashboard frmDash = new FrmDashboard();
                frmDash.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username or Password", "Error");
            }


            
        }

        private void cbPassword_CheckedChanged(object sender, EventArgs e)
        {
            if (cbPassword.Checked) 
            {
                txtPassword.UseSystemPasswordChar = false; 
            }
            else 
            {
                txtPassword.UseSystemPasswordChar = true; 
            }

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

            

        }
    }
}
