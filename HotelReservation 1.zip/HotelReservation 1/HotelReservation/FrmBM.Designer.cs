﻿namespace HotelReservation
{
    partial class FrmBM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPayment = new System.Windows.Forms.TextBox();
            this.cbRoomtype = new System.Windows.Forms.ComboBox();
            this.numNorooms = new System.Windows.Forms.NumericUpDown();
            this.dtpCheckin = new System.Windows.Forms.DateTimePicker();
            this.lblNorooms = new System.Windows.Forms.Label();
            this.lblPayment = new System.Windows.Forms.Label();
            this.lblCheckin = new System.Windows.Forms.Label();
            this.lblReservationid = new System.Windows.Forms.Label();
            this.lbblCheckout = new System.Windows.Forms.Label();
            this.lblRoomtype = new System.Windows.Forms.Label();
            this.dtpCheckout = new System.Windows.Forms.DateTimePicker();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnBackBM = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnDeleteBM = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtRid = new System.Windows.Forms.TextBox();
            this.dgvBM = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numNorooms)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBM)).BeginInit();
            this.SuspendLayout();
            // 
            // txtPayment
            // 
            this.txtPayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPayment.ForeColor = System.Drawing.Color.Red;
            this.txtPayment.Location = new System.Drawing.Point(243, 404);
            this.txtPayment.Name = "txtPayment";
            this.txtPayment.ReadOnly = true;
            this.txtPayment.Size = new System.Drawing.Size(200, 34);
            this.txtPayment.TabIndex = 29;
            this.txtPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPayment.TextChanged += new System.EventHandler(this.txtPayment_TextChanged);
            // 
            // cbRoomtype
            // 
            this.cbRoomtype.FormattingEnabled = true;
            this.cbRoomtype.Items.AddRange(new object[] {
            "Luxury",
            "Delux",
            "Single"});
            this.cbRoomtype.Location = new System.Drawing.Point(243, 196);
            this.cbRoomtype.Name = "cbRoomtype";
            this.cbRoomtype.Size = new System.Drawing.Size(200, 24);
            this.cbRoomtype.TabIndex = 28;
            this.cbRoomtype.SelectedIndexChanged += new System.EventHandler(this.cbRoomtype_SelectedIndexChanged);
            // 
            // numNorooms
            // 
            this.numNorooms.Location = new System.Drawing.Point(242, 250);
            this.numNorooms.Name = "numNorooms";
            this.numNorooms.Size = new System.Drawing.Size(201, 22);
            this.numNorooms.TabIndex = 25;
            this.numNorooms.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numNorooms.ValueChanged += new System.EventHandler(this.numNorooms_ValueChanged);
            // 
            // dtpCheckin
            // 
            this.dtpCheckin.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCheckin.Location = new System.Drawing.Point(244, 295);
            this.dtpCheckin.Name = "dtpCheckin";
            this.dtpCheckin.Size = new System.Drawing.Size(200, 22);
            this.dtpCheckin.TabIndex = 24;
            // 
            // lblNorooms
            // 
            this.lblNorooms.AutoSize = true;
            this.lblNorooms.BackColor = System.Drawing.Color.Transparent;
            this.lblNorooms.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNorooms.ForeColor = System.Drawing.Color.White;
            this.lblNorooms.Location = new System.Drawing.Point(47, 242);
            this.lblNorooms.Name = "lblNorooms";
            this.lblNorooms.Size = new System.Drawing.Size(140, 29);
            this.lblNorooms.TabIndex = 22;
            this.lblNorooms.Text = "No Rooms :";
            // 
            // lblPayment
            // 
            this.lblPayment.AutoSize = true;
            this.lblPayment.BackColor = System.Drawing.Color.Transparent;
            this.lblPayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPayment.ForeColor = System.Drawing.Color.White;
            this.lblPayment.Location = new System.Drawing.Point(51, 403);
            this.lblPayment.Name = "lblPayment";
            this.lblPayment.Size = new System.Drawing.Size(118, 29);
            this.lblPayment.TabIndex = 21;
            this.lblPayment.Text = "Payment :";
            // 
            // lblCheckin
            // 
            this.lblCheckin.AutoSize = true;
            this.lblCheckin.BackColor = System.Drawing.Color.Transparent;
            this.lblCheckin.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCheckin.ForeColor = System.Drawing.Color.White;
            this.lblCheckin.Location = new System.Drawing.Point(47, 290);
            this.lblCheckin.Name = "lblCheckin";
            this.lblCheckin.Size = new System.Drawing.Size(118, 29);
            this.lblCheckin.TabIndex = 18;
            this.lblCheckin.Text = "Check In :";
            // 
            // lblReservationid
            // 
            this.lblReservationid.AutoSize = true;
            this.lblReservationid.BackColor = System.Drawing.Color.Transparent;
            this.lblReservationid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReservationid.ForeColor = System.Drawing.Color.White;
            this.lblReservationid.Location = new System.Drawing.Point(25, 55);
            this.lblReservationid.Name = "lblReservationid";
            this.lblReservationid.Size = new System.Drawing.Size(182, 29);
            this.lblReservationid.TabIndex = 17;
            this.lblReservationid.Text = "Reservation ID :";
            // 
            // lbblCheckout
            // 
            this.lbblCheckout.AutoSize = true;
            this.lbblCheckout.BackColor = System.Drawing.Color.Transparent;
            this.lbblCheckout.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbblCheckout.ForeColor = System.Drawing.Color.White;
            this.lbblCheckout.Location = new System.Drawing.Point(50, 338);
            this.lbblCheckout.Name = "lbblCheckout";
            this.lbblCheckout.Size = new System.Drawing.Size(137, 29);
            this.lbblCheckout.TabIndex = 32;
            this.lbblCheckout.Text = "Check Out :";
            // 
            // lblRoomtype
            // 
            this.lblRoomtype.AutoSize = true;
            this.lblRoomtype.BackColor = System.Drawing.Color.Transparent;
            this.lblRoomtype.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRoomtype.ForeColor = System.Drawing.Color.White;
            this.lblRoomtype.Location = new System.Drawing.Point(50, 189);
            this.lblRoomtype.Name = "lblRoomtype";
            this.lblRoomtype.Size = new System.Drawing.Size(151, 29);
            this.lblRoomtype.TabIndex = 33;
            this.lblRoomtype.Text = "Room Type :";
            // 
            // dtpCheckout
            // 
            this.dtpCheckout.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpCheckout.Location = new System.Drawing.Point(243, 345);
            this.dtpCheckout.Name = "dtpCheckout";
            this.dtpCheckout.Size = new System.Drawing.Size(200, 22);
            this.dtpCheckout.TabIndex = 35;
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Location = new System.Drawing.Point(319, 460);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(124, 44);
            this.btnSave.TabIndex = 36;
            this.btnSave.Text = "DONE";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnBackBM
            // 
            this.btnBackBM.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnBackBM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackBM.Location = new System.Drawing.Point(36, 560);
            this.btnBackBM.Name = "btnBackBM";
            this.btnBackBM.Size = new System.Drawing.Size(128, 49);
            this.btnBackBM.TabIndex = 63;
            this.btnBackBM.Text = " Back";
            this.btnBackBM.UseVisualStyleBackColor = false;
            this.btnBackBM.Click += new System.EventHandler(this.btnBackBM_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnLoad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Location = new System.Drawing.Point(556, 483);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(192, 49);
            this.btnLoad.TabIndex = 64;
            this.btnLoad.Text = "All Reservations";
            this.btnLoad.UseVisualStyleBackColor = false;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnDeleteBM
            // 
            this.btnDeleteBM.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnDeleteBM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteBM.Location = new System.Drawing.Point(1024, 483);
            this.btnDeleteBM.Name = "btnDeleteBM";
            this.btnDeleteBM.Size = new System.Drawing.Size(128, 49);
            this.btnDeleteBM.TabIndex = 65;
            this.btnDeleteBM.Text = "Delete";
            this.btnDeleteBM.UseVisualStyleBackColor = false;
            this.btnDeleteBM.Click += new System.EventHandler(this.btnDeleteBM_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(831, 488);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(124, 44);
            this.button1.TabIndex = 68;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.ForeColor = System.Drawing.Color.Black;
            this.btnSearch.Location = new System.Drawing.Point(260, 103);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(132, 47);
            this.btnSearch.TabIndex = 71;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtRid);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.lblReservationid);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(485, 169);
            this.groupBox1.TabIndex = 74;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Room Reservation";
            // 
            // txtRid
            // 
            this.txtRid.Location = new System.Drawing.Point(227, 54);
            this.txtRid.Name = "txtRid";
            this.txtRid.Size = new System.Drawing.Size(207, 30);
            this.txtRid.TabIndex = 54;
            // 
            // dgvBM
            // 
            this.dgvBM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBM.Location = new System.Drawing.Point(556, 21);
            this.dgvBM.Name = "dgvBM";
            this.dgvBM.RowHeadersWidth = 51;
            this.dgvBM.RowTemplate.Height = 24;
            this.dgvBM.Size = new System.Drawing.Size(596, 411);
            this.dgvBM.TabIndex = 0;
            this.dgvBM.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(56, 460);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(156, 44);
            this.button2.TabIndex = 75;
            this.button2.Text = "Calculate";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // FrmBM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.GhostWhite;
            this.BackgroundImage = global::HotelReservation.Properties.Resources.BaackgroundGold;
            this.ClientSize = new System.Drawing.Size(1174, 650);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnDeleteBM);
            this.Controls.Add(this.btnLoad);
            this.Controls.Add(this.btnBackBM);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.dtpCheckout);
            this.Controls.Add(this.lblRoomtype);
            this.Controls.Add(this.lbblCheckout);
            this.Controls.Add(this.txtPayment);
            this.Controls.Add(this.cbRoomtype);
            this.Controls.Add(this.numNorooms);
            this.Controls.Add(this.dtpCheckin);
            this.Controls.Add(this.lblNorooms);
            this.Controls.Add(this.lblPayment);
            this.Controls.Add(this.lblCheckin);
            this.Controls.Add(this.dgvBM);
            this.Name = "FrmBM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Room Reservation";
            this.Load += new System.EventHandler(this.FrmBM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numNorooms)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtPayment;
        private System.Windows.Forms.ComboBox cbRoomtype;
        private System.Windows.Forms.NumericUpDown numNorooms;
        private System.Windows.Forms.DateTimePicker dtpCheckin;
        private System.Windows.Forms.Label lblNorooms;
        private System.Windows.Forms.Label lblPayment;
        private System.Windows.Forms.Label lblCheckin;
        private System.Windows.Forms.Label lblReservationid;
        private System.Windows.Forms.Label lbblCheckout;
        private System.Windows.Forms.Label lblRoomtype;
        private System.Windows.Forms.DateTimePicker dtpCheckout;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnBackBM;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnDeleteBM;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtRid;
        private System.Windows.Forms.DataGridView dgvBM;
        private System.Windows.Forms.Button button2;
    }
}