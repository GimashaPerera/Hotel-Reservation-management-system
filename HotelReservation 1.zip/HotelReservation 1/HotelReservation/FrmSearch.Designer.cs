﻿namespace HotelReservation
{
    partial class FrmSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnSearchS = new System.Windows.Forms.Button();
            this.txtSearchS = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnBackS = new System.Windows.Forms.Button();
            this.lblcheckin = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblrtype = new System.Windows.Forms.Label();
            this.lblRidS = new System.Windows.Forms.Label();
            this.lblrt = new System.Windows.Forms.Label();
            this.lblcin = new System.Windows.Forms.Label();
            this.lblpayment = new System.Windows.Forms.Label();
            this.l = new System.Windows.Forms.Label();
            this.lblcheckout = new System.Windows.Forms.Label();
            this.lblcout = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.btnSearchS);
            this.groupBox1.Controls.Add(this.txtSearchS);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(250, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(527, 146);
            this.groupBox1.TabIndex = 64;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Search Reservation";
            // 
            // btnSearchS
            // 
            this.btnSearchS.BackColor = System.Drawing.Color.White;
            this.btnSearchS.ForeColor = System.Drawing.Color.Black;
            this.btnSearchS.Location = new System.Drawing.Point(337, 94);
            this.btnSearchS.Name = "btnSearchS";
            this.btnSearchS.Size = new System.Drawing.Size(90, 36);
            this.btnSearchS.TabIndex = 17;
            this.btnSearchS.Text = "Search";
            this.btnSearchS.UseVisualStyleBackColor = false;
            this.btnSearchS.Click += new System.EventHandler(this.btnSearchS_Click);
            // 
            // txtSearchS
            // 
            this.txtSearchS.Location = new System.Drawing.Point(305, 46);
            this.txtSearchS.Name = "txtSearchS";
            this.txtSearchS.Size = new System.Drawing.Size(155, 30);
            this.txtSearchS.TabIndex = 16;
            this.txtSearchS.TextChanged += new System.EventHandler(this.txtSearchS_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(6, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(267, 29);
            this.label1.TabIndex = 15;
            this.label1.Text = "Enter Reservation ID :";
            // 
            // btnBackS
            // 
            this.btnBackS.Location = new System.Drawing.Point(46, 524);
            this.btnBackS.Name = "btnBackS";
            this.btnBackS.Size = new System.Drawing.Size(148, 34);
            this.btnBackS.TabIndex = 65;
            this.btnBackS.Text = "< Back";
            this.btnBackS.UseVisualStyleBackColor = true;
            this.btnBackS.Click += new System.EventHandler(this.btnBackS_Click);
            // 
            // lblcheckin
            // 
            this.lblcheckin.AutoSize = true;
            this.lblcheckin.BackColor = System.Drawing.Color.Transparent;
            this.lblcheckin.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcheckin.ForeColor = System.Drawing.Color.Snow;
            this.lblcheckin.Location = new System.Drawing.Point(253, 332);
            this.lblcheckin.Name = "lblcheckin";
            this.lblcheckin.Size = new System.Drawing.Size(164, 43);
            this.lblcheckin.TabIndex = 69;
            this.lblcheckin.Text = "Check in :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Snow;
            this.label2.Location = new System.Drawing.Point(253, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(250, 43);
            this.label2.TabIndex = 67;
            this.label2.Text = "Reservation ID :";
            // 
            // lblrtype
            // 
            this.lblrtype.AutoSize = true;
            this.lblrtype.BackColor = System.Drawing.Color.Transparent;
            this.lblrtype.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrtype.ForeColor = System.Drawing.Color.Snow;
            this.lblrtype.Location = new System.Drawing.Point(253, 263);
            this.lblrtype.Name = "lblrtype";
            this.lblrtype.Size = new System.Drawing.Size(204, 43);
            this.lblrtype.TabIndex = 68;
            this.lblrtype.Text = "Room Type :";
            // 
            // lblRidS
            // 
            this.lblRidS.AutoSize = true;
            this.lblRidS.BackColor = System.Drawing.Color.Transparent;
            this.lblRidS.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRidS.ForeColor = System.Drawing.Color.Snow;
            this.lblRidS.Location = new System.Drawing.Point(672, 199);
            this.lblRidS.Name = "lblRidS";
            this.lblRidS.Size = new System.Drawing.Size(87, 43);
            this.lblRidS.TabIndex = 70;
            this.lblRidS.Text = "0000";
            this.lblRidS.Click += new System.EventHandler(this.lblRidS_Click);
            // 
            // lblrt
            // 
            this.lblrt.AutoSize = true;
            this.lblrt.BackColor = System.Drawing.Color.Transparent;
            this.lblrt.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrt.ForeColor = System.Drawing.Color.Snow;
            this.lblrt.Location = new System.Drawing.Point(643, 263);
            this.lblrt.Name = "lblrt";
            this.lblrt.Size = new System.Drawing.Size(87, 43);
            this.lblrt.TabIndex = 74;
            this.lblrt.Text = "0000";
            // 
            // lblcin
            // 
            this.lblcin.AutoSize = true;
            this.lblcin.BackColor = System.Drawing.Color.Transparent;
            this.lblcin.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcin.ForeColor = System.Drawing.Color.Snow;
            this.lblcin.Location = new System.Drawing.Point(547, 332);
            this.lblcin.Name = "lblcin";
            this.lblcin.Size = new System.Drawing.Size(87, 43);
            this.lblcin.TabIndex = 75;
            this.lblcin.Text = "0000";
            // 
            // lblpayment
            // 
            this.lblpayment.AutoSize = true;
            this.lblpayment.BackColor = System.Drawing.Color.Transparent;
            this.lblpayment.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpayment.ForeColor = System.Drawing.Color.Snow;
            this.lblpayment.Location = new System.Drawing.Point(672, 459);
            this.lblpayment.Name = "lblpayment";
            this.lblpayment.Size = new System.Drawing.Size(87, 43);
            this.lblpayment.TabIndex = 78;
            this.lblpayment.Text = "0000";
            // 
            // l
            // 
            this.l.AutoSize = true;
            this.l.BackColor = System.Drawing.Color.Transparent;
            this.l.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l.ForeColor = System.Drawing.Color.Snow;
            this.l.Location = new System.Drawing.Point(253, 459);
            this.l.Name = "l";
            this.l.Size = new System.Drawing.Size(164, 43);
            this.l.TabIndex = 77;
            this.l.Text = "Payment :";
            // 
            // lblcheckout
            // 
            this.lblcheckout.AutoSize = true;
            this.lblcheckout.BackColor = System.Drawing.Color.Transparent;
            this.lblcheckout.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcheckout.ForeColor = System.Drawing.Color.Snow;
            this.lblcheckout.Location = new System.Drawing.Point(253, 394);
            this.lblcheckout.Name = "lblcheckout";
            this.lblcheckout.Size = new System.Drawing.Size(185, 43);
            this.lblcheckout.TabIndex = 79;
            this.lblcheckout.Text = "Check out :";
            // 
            // lblcout
            // 
            this.lblcout.AutoSize = true;
            this.lblcout.BackColor = System.Drawing.Color.Transparent;
            this.lblcout.Font = new System.Drawing.Font("Arial Narrow", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcout.ForeColor = System.Drawing.Color.Snow;
            this.lblcout.Location = new System.Drawing.Point(547, 394);
            this.lblcout.Name = "lblcout";
            this.lblcout.Size = new System.Drawing.Size(87, 43);
            this.lblcout.TabIndex = 80;
            this.lblcout.Text = "0000";
            // 
            // FrmSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HotelReservation.Properties.Resources.BaackgroundGold;
            this.ClientSize = new System.Drawing.Size(1174, 650);
            this.Controls.Add(this.lblcout);
            this.Controls.Add(this.lblcheckout);
            this.Controls.Add(this.lblpayment);
            this.Controls.Add(this.l);
            this.Controls.Add(this.lblcin);
            this.Controls.Add(this.lblrt);
            this.Controls.Add(this.lblRidS);
            this.Controls.Add(this.lblcheckin);
            this.Controls.Add(this.lblrtype);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnBackS);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmSearch";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Search Reservation";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnSearchS;
        private System.Windows.Forms.TextBox txtSearchS;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnBackS;
        private System.Windows.Forms.Label lblcheckin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblrtype;
        private System.Windows.Forms.Label lblRidS;
        private System.Windows.Forms.Label lblrt;
        private System.Windows.Forms.Label lblcin;
        private System.Windows.Forms.Label lblpayment;
        private System.Windows.Forms.Label l;
        private System.Windows.Forms.Label lblcheckout;
        private System.Windows.Forms.Label lblcout;
    }
}