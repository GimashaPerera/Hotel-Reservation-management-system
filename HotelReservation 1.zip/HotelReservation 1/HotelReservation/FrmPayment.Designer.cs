﻿namespace HotelReservation
{
    partial class FrmPayment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvPayments = new System.Windows.Forms.DataGridView();
            this.btnDeleteP = new System.Windows.Forms.Button();
            this.btnUpdateP = new System.Windows.Forms.Button();
            this.btnBackP = new System.Windows.Forms.Button();
            this.gbSearch = new System.Windows.Forms.GroupBox();
            this.btnSearchP = new System.Windows.Forms.Button();
            this.txtsearchP = new System.Windows.Forms.TextBox();
            this.lblReserveid = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayments)).BeginInit();
            this.gbSearch.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvPayments
            // 
            this.dgvPayments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPayments.Location = new System.Drawing.Point(21, 77);
            this.dgvPayments.Name = "dgvPayments";
            this.dgvPayments.RowHeadersWidth = 51;
            this.dgvPayments.RowTemplate.Height = 24;
            this.dgvPayments.Size = new System.Drawing.Size(970, 274);
            this.dgvPayments.TabIndex = 1;
            this.dgvPayments.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // btnDeleteP
            // 
            this.btnDeleteP.Location = new System.Drawing.Point(797, 412);
            this.btnDeleteP.Name = "btnDeleteP";
            this.btnDeleteP.Size = new System.Drawing.Size(148, 34);
            this.btnDeleteP.TabIndex = 58;
            this.btnDeleteP.Text = "Delete";
            this.btnDeleteP.UseVisualStyleBackColor = true;
            this.btnDeleteP.Click += new System.EventHandler(this.btnDeleteP_Click);
            // 
            // btnUpdateP
            // 
            this.btnUpdateP.Location = new System.Drawing.Point(593, 412);
            this.btnUpdateP.Name = "btnUpdateP";
            this.btnUpdateP.Size = new System.Drawing.Size(148, 34);
            this.btnUpdateP.TabIndex = 59;
            this.btnUpdateP.Text = "Update";
            this.btnUpdateP.UseVisualStyleBackColor = true;
            this.btnUpdateP.Click += new System.EventHandler(this.btnUpdateP_Click);
            // 
            // btnBackP
            // 
            this.btnBackP.Location = new System.Drawing.Point(21, 548);
            this.btnBackP.Name = "btnBackP";
            this.btnBackP.Size = new System.Drawing.Size(148, 34);
            this.btnBackP.TabIndex = 61;
            this.btnBackP.Text = "< Back";
            this.btnBackP.UseVisualStyleBackColor = true;
            this.btnBackP.Click += new System.EventHandler(this.btnBackP_Click);
            // 
            // gbSearch
            // 
            this.gbSearch.BackColor = System.Drawing.Color.Transparent;
            this.gbSearch.Controls.Add(this.btnSearchP);
            this.gbSearch.Controls.Add(this.txtsearchP);
            this.gbSearch.Controls.Add(this.lblReserveid);
            this.gbSearch.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSearch.ForeColor = System.Drawing.Color.White;
            this.gbSearch.Location = new System.Drawing.Point(21, 380);
            this.gbSearch.Name = "gbSearch";
            this.gbSearch.Size = new System.Drawing.Size(527, 146);
            this.gbSearch.TabIndex = 63;
            this.gbSearch.TabStop = false;
            this.gbSearch.Text = "Search Reservation";
            // 
            // btnSearchP
            // 
            this.btnSearchP.BackColor = System.Drawing.Color.White;
            this.btnSearchP.ForeColor = System.Drawing.Color.Black;
            this.btnSearchP.Location = new System.Drawing.Point(337, 94);
            this.btnSearchP.Name = "btnSearchP";
            this.btnSearchP.Size = new System.Drawing.Size(90, 36);
            this.btnSearchP.TabIndex = 17;
            this.btnSearchP.Text = "Search";
            this.btnSearchP.UseVisualStyleBackColor = false;
            this.btnSearchP.Click += new System.EventHandler(this.btnSearchP_Click);
            // 
            // txtsearchP
            // 
            this.txtsearchP.Location = new System.Drawing.Point(305, 46);
            this.txtsearchP.Name = "txtsearchP";
            this.txtsearchP.Size = new System.Drawing.Size(155, 30);
            this.txtsearchP.TabIndex = 16;
            // 
            // lblReserveid
            // 
            this.lblReserveid.AutoSize = true;
            this.lblReserveid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReserveid.ForeColor = System.Drawing.Color.White;
            this.lblReserveid.Location = new System.Drawing.Point(6, 46);
            this.lblReserveid.Name = "lblReserveid";
            this.lblReserveid.Size = new System.Drawing.Size(267, 29);
            this.lblReserveid.TabIndex = 15;
            this.lblReserveid.Text = "Enter Reservation ID :";
            this.lblReserveid.Click += new System.EventHandler(this.label1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(25, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(206, 38);
            this.label5.TabIndex = 73;
            this.label5.Text = "PAYMENTS";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(692, 478);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(148, 34);
            this.button1.TabIndex = 74;
            this.button1.Text = "Load ";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmPayment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HotelReservation.Properties.Resources.BaackgroundGold;
            this.ClientSize = new System.Drawing.Size(1174, 650);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.gbSearch);
            this.Controls.Add(this.btnBackP);
            this.Controls.Add(this.btnUpdateP);
            this.Controls.Add(this.btnDeleteP);
            this.Controls.Add(this.dgvPayments);
            this.Name = "FrmPayment";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Payment";
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayments)).EndInit();
            this.gbSearch.ResumeLayout(false);
            this.gbSearch.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPayments;
        private System.Windows.Forms.Button btnDeleteP;
        private System.Windows.Forms.Button btnUpdateP;
        private System.Windows.Forms.Button btnBackP;
        private System.Windows.Forms.GroupBox gbSearch;
        private System.Windows.Forms.Button btnSearchP;
        private System.Windows.Forms.TextBox txtsearchP;
        private System.Windows.Forms.Label lblReserveid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
    }
}