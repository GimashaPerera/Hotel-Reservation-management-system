﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class FrmPrices : Form
    {
        public FrmPrices()
        {
            InitializeComponent();
        }

        private void btnBackPrice_Click(object sender, EventArgs e)
        {
            FrmDashboard frmdash = new FrmDashboard();
            frmdash.Show();
            this.Close();
        }

        private void FrmPrices_Load(object sender, EventArgs e)
        {
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();

            string sql = "SELECT * FROM tblPrice"; // Load all records
            SqlCommand com = new SqlCommand(sql, con);

            SqlDataAdapter dap = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            dap.Fill(dt);

            dgvPrice.DataSource = dt; // Bind to DataGridView
            dgvPrice.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; 
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dgvPrice_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
