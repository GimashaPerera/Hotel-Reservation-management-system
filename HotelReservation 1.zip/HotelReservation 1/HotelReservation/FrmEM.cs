﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class FrmEM : Form
    {
        public FrmEM()
        {
            InitializeComponent();
        }

        private void btnAddEM_Click(object sender, EventArgs e)
        {
            // Check if any fields are empty
            if (string.IsNullOrWhiteSpace(txteid.Text) ||
                string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtAge.Text) ||
                string.IsNullOrWhiteSpace(txtNic.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtContact.Text))
            {
                MessageBox.Show("Please fill all the blanks", "Error");
                
            }
            else
            {
                //connection
                string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
                SqlConnection con = new SqlConnection(str);
                con.Open();


                //command
                string sql = "INSERT INTO Employee (Empid, Ename, Eage, Enic, Eaddress, Econtact) " +
                                     "VALUES (@eid, @ename, @eage, @enic, @eaddress, @econtact)";
                SqlCommand com = new SqlCommand(sql, con);
                com.Parameters.AddWithValue("@eid",txteid.Text);
                com.Parameters.AddWithValue("@ename", txtName.Text);
                com.Parameters.AddWithValue("@eage", txtAge.Text);
                com.Parameters.AddWithValue("@enic", txtNic.Text);
                com.Parameters.AddWithValue("@eaddress", txtAddress.Text);
                com.Parameters.AddWithValue("@econtact", txtContact.Text);


                //Execute command to insert data
                int ret = com.ExecuteNonQuery();
                MessageBox.Show("No of Records Inserted:" + ret, "Information");

                //disconect
                con.Close();

                this.txtName.Clear();
                this.txtAge.Clear();
                this.txtAddress.Clear();
                this.txtNic.Clear();
                this.txtContact.Clear();


                //call to load button click
                btnEditEM_Click(sender, e);
            }

        }

        private void btnBackEM_Click(object sender, EventArgs e)
        {
            FrmDashboard frmdash = new FrmDashboard();
            frmdash.Show();
            this.Hide();
        }

        private void FrmEM_Load(object sender, EventArgs e)
        {

        }

        private void btnClearEM_Click(object sender, EventArgs e)
        {

        }

        private void btnEditEM_Click(object sender, EventArgs e)
        {

            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM Employee ORDER BY Empid ASC";
            SqlCommand com = new SqlCommand(sql, con);


            //Access data using data reader
            SqlDataAdapter dap = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            dap.Fill(ds);


            this.dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            //disconnect from Server
            con.Close();


        }

        private void btnDeleteEM_Click(object sender, EventArgs e)
        {
            //connection
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();


            //command
            string sql = "DELETE FROM Employee WHERE Empid=@eid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@eid", txteid.Text);
            com.Parameters.AddWithValue("@ename", txtName.Text);
            com.Parameters.AddWithValue("@eage", txtAge.Text);
            com.Parameters.AddWithValue("@enic", txtNic.Text);
            com.Parameters.AddWithValue("@eaddress", txtAddress.Text);
            com.Parameters.AddWithValue("@econtact", txtContact.Text);

            //Execute command to DElete data
            string msgdel = MessageBox.Show("Are you sure you want to delete?", "Warning",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning).ToString();

            if (msgdel == "Yes")
            {
                int del = com.ExecuteNonQuery();
                MessageBox.Show("No of Records Deleted:" + del, "Information");
            }
            //disconect
            con.Close();


            this.txteid.Clear();
            this.txtName.Clear();
            this.txtAge.Clear();
            this.txtNic.Clear();
            this.txtAddress.Clear();
            this.txtContact.Clear();



            //call to load button click
            btnEditEM_Click(sender, e);

        }

        private void btnSearchEM_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //connection
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();


            //command
            string sql = "UPDATE Employee SET Empid=@eid,Ename=@ename,Eage=@eage,Eaddress=@eaddress,Econtact=@econtact WHERE Empid=@eid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@eid", txteid.Text);
            com.Parameters.AddWithValue("@ename", txtName.Text);
            com.Parameters.AddWithValue("@eage", txtAge.Text);
            com.Parameters.AddWithValue("@enic", txtNic.Text);
            com.Parameters.AddWithValue("@eaddress", txtAddress.Text);
            com.Parameters.AddWithValue("@econtact", txtContact.Text);



            //Execute command to insert data
            int ret = com.ExecuteNonQuery();
            MessageBox.Show("No of Records Updated:" + ret, "Information");

            //disconect
            con.Close();

            //call to load button click
            btnEditEM_Click(sender, e);

            this.txteid.Clear();
            this.txtName.Clear();
            this.txtAge.Clear();
            this.txtNic.Clear();
            this.txtAddress.Clear();
            this.txtContact.Clear();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM Employee WHERE Empid=@eid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@eid", this.txteid.Text);


            //Access data using data reader
            SqlDataReader dr = com.ExecuteReader();  // dr used to point"s the towards the data

            if (dr.Read() == true)
            {


                //Bind data will contrals

                this.txteid.Text = dr.GetValue(0).ToString();
                this.txtName.Text = dr.GetValue(1).ToString();
                this.txtAge.Text = dr.GetValue(2).ToString();
                this.txtNic.Text = dr.GetValue(3).ToString();
                this.txtAddress.Text = dr.GetValue(4).ToString();
                this.txtContact.Text = dr.GetValue(5).ToString();
                


            }
            else
            {
                MessageBox.Show("No records found");
            }


            //disconnect from Server
            con.Close();
        }
    }
}
