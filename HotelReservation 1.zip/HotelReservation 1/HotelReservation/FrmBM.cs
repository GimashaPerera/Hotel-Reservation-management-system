﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace HotelReservation
{
    public partial class FrmBM : Form
    {
        public FrmBM()
        {
            InitializeComponent();
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FrmBM_Load(object sender, EventArgs e)
        {

        }

        private void btnBackBM_Click(object sender, EventArgs e)
        {
            FrmDashboard frmDash = new FrmDashboard();
            frmDash.Show();
            this.Hide();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // fields are empty
            if (string.IsNullOrWhiteSpace(txtRid.Text) ||
                string.IsNullOrWhiteSpace(cbRoomtype.Text) ||
                string.IsNullOrWhiteSpace(txtPayment.Text))

            {
                MessageBox.Show("Please fill all the blanks", "Error");


            }
            else
            {


                //connection
                string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
                SqlConnection con = new SqlConnection(str);
                con.Open();


                //command
                string sql = "INSERT INTO tblBM1(rid,rtype,checkin,checkout,payment,norooms) VALUES (@rid,@rtype,@checkin,@checkout,@payment,@norooms)";
                SqlCommand com = new SqlCommand(sql, con);
                com.Parameters.AddWithValue("@rid", this.txtRid.Text);
                com.Parameters.AddWithValue("@rtype", this.cbRoomtype.Text);
                com.Parameters.AddWithValue("@checkin", this.dtpCheckin.Text);
                com.Parameters.AddWithValue("@checkout", this.dtpCheckout.Text);
                com.Parameters.AddWithValue("@payment", this.txtPayment.Text);
                com.Parameters.AddWithValue("@norooms", Convert.ToInt32(numNorooms.Value));

                //Execute command to insert data
                int ret = com.ExecuteNonQuery();
                MessageBox.Show("No of Records Inserted:" + ret, "Information");


                //disconect
                con.Close();

                //call to load button click
                btnLoad_Click(sender, e);

                this.txtPayment.Clear();
                this.txtRid.Clear();
                this.numNorooms.Value = numNorooms.Minimum;
                this.cbRoomtype.SelectedIndex = -1;

            }
        }

        private void btnDeleteBM_Click(object sender, EventArgs e)
        {
            //connection
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();


            //command
            string sql = "DELETE FROM tblBM1 WHERE rid=@rid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@rid", this.txtRid.Text);
            com.Parameters.AddWithValue("@rtype", this.cbRoomtype.Text);
            com.Parameters.AddWithValue("@checkin",this.dtpCheckin.Text);
            com.Parameters.AddWithValue("@checkout",this.dtpCheckout.Text);
            com.Parameters.AddWithValue("@payment", this.txtPayment.Text);
            com.Parameters.AddWithValue("@norooms", Convert.ToInt32(numNorooms.Value));

            //Execute command to DElete data
            string msgret = MessageBox.Show("Are you sure you want to delete?", "Warning",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning).ToString();

            if (msgret == "Yes")
            {
                int ret = com.ExecuteNonQuery();
                MessageBox.Show("No of Records Deleted:" + ret, "Information");
            }
            //disconect
            con.Close();


            //call to load button click
            btnLoad_Click(sender, e);

            this.txtPayment.Clear();
            this.txtRid.Clear();
            this.numNorooms.Value = numNorooms.Minimum;
            this.cbRoomtype.SelectedIndex = -1;
        }

        private void btnSearchBM_Click(object sender, EventArgs e)
        {

        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM tblBM1 ORDER BY rid ASC";
            SqlCommand com = new SqlCommand(sql, con);


            //Access data using data reader
            SqlDataAdapter dap = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            dap.Fill(ds);


            this.dgvBM.DataSource = ds.Tables[0];


            //disconnect from Server
            con.Close();
        }

        private void txtPayment_TextChanged(object sender, EventArgs e)
        {

        }

        private void numNorooms_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //connection
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();


            //command
            string sql = "UPDATE tblBM1 SET rid=@rid,rtype=@rtype,checkin=@checkin,checkout=@checkout,payment=@payment,norooms=@norooms WHERE rid=@rid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@rid", this.txtRid.Text);
            com.Parameters.AddWithValue("@rtype", this.cbRoomtype.Text);
            com.Parameters.AddWithValue("@checkin", this.dtpCheckin.Text);
            com.Parameters.AddWithValue("@checkout", this.dtpCheckout.Text);
            com.Parameters.AddWithValue("@payment", this.txtPayment.Text);
            com.Parameters.AddWithValue("@norooms", Convert.ToInt32(numNorooms.Value));


            //Execute command to insert data
            int ret = com.ExecuteNonQuery();
            MessageBox.Show("No of Records Updated:" + ret, "Information");

            //disconect
            con.Close();

            //call to load button click
            btnLoad_Click(sender, e);


            this.txtPayment.Clear();
            this.txtRid.Clear();
            this.numNorooms.Value = numNorooms.Minimum;
            this.cbRoomtype.SelectedIndex = -1;

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM tblBM1 WHERE rid=@rid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@rid", this.txtRid.Text);


            //Access data using data reader
            SqlDataReader dr = com.ExecuteReader();  // dr used to point"s the towards the data

            if (dr.Read() == true)
            {


                //Bind data will contrals

                this.txtRid.Text = dr.GetValue(0).ToString();
                this.cbRoomtype.Text = dr.GetValue(1).ToString();
                this.dtpCheckin.Text = dr.GetValue(2).ToString();
                this.dtpCheckout.Text = dr.GetValue(3).ToString();
                this.txtPayment.Text = dr.GetValue(4).ToString();
                this.numNorooms.Value = Convert.ToDecimal(dr.GetValue(5));


            }
            else
            {
                MessageBox.Show("No records found");
            }


            //disconnect from Server
            con.Close();
        }

        private void cbRoomtype_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            double roomcost = 0.0;
            int nodays = 0, norooms = 0;
            double pay = 0.0;
           



            // roomcost calculation

            if (this.cbRoomtype.Text == "Luxury" )
            {
                roomcost = 30000;
            }
            else if (this.cbRoomtype.Text == "Delux")
            {
                roomcost = 20000;
            }
            else if (this.cbRoomtype.Text == "Single")
            {
                roomcost = 10000;
            }

            //no of Rooms
            norooms = Convert.ToInt32(this.numNorooms.Value);

            //no of days
            DateTime cin = Convert.ToDateTime(this.dtpCheckin.Text);
            DateTime cout = Convert.ToDateTime(this.dtpCheckout.Text);

            if(cin == cout)
            {
                nodays = 1;
            }
            else
            {
                TimeSpan ts = cout - cin;
                nodays = ts.Days;
            }

            //payment
            pay = roomcost* norooms * nodays;

            //Display payment
            this.txtPayment.Text = pay.ToString();


        }
    }
}
