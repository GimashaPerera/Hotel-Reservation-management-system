﻿namespace HotelReservation
{
    partial class FrmPrices
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvPrice = new System.Windows.Forms.DataGridView();
            this.label2 = new System.Windows.Forms.Label();
            this.btnBackPrice = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrice)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvPrice
            // 
            this.dgvPrice.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPrice.Location = new System.Drawing.Point(266, 152);
            this.dgvPrice.Name = "dgvPrice";
            this.dgvPrice.RowHeadersWidth = 51;
            this.dgvPrice.RowTemplate.Height = 24;
            this.dgvPrice.Size = new System.Drawing.Size(656, 252);
            this.dgvPrice.TabIndex = 0;
            this.dgvPrice.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPrice_CellContentClick);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Snow;
            this.label2.Location = new System.Drawing.Point(260, 91);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 35);
            this.label2.TabIndex = 11;
            this.label2.Text = "PRICE LIST";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // btnBackPrice
            // 
            this.btnBackPrice.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnBackPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackPrice.Location = new System.Drawing.Point(56, 520);
            this.btnBackPrice.Name = "btnBackPrice";
            this.btnBackPrice.Size = new System.Drawing.Size(111, 34);
            this.btnBackPrice.TabIndex = 66;
            this.btnBackPrice.Text = "Back";
            this.btnBackPrice.UseVisualStyleBackColor = false;
            this.btnBackPrice.Click += new System.EventHandler(this.btnBackPrice_Click);
            // 
            // FrmPrices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HotelReservation.Properties.Resources.BaackgroundGold;
            this.ClientSize = new System.Drawing.Size(1174, 650);
            this.Controls.Add(this.btnBackPrice);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.dgvPrice);
            this.Name = "FrmPrices";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmPrices";
            this.Load += new System.EventHandler(this.FrmPrices_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPrice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvPrice;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnBackPrice;
    }
}