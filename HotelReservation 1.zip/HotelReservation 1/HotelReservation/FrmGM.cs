﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class FrmGM : Form
    {
        public FrmGM()
        {
            InitializeComponent();
        }

        private void FrmGM_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
           
           
        }

        private void btnBackGM_Click(object sender, EventArgs e)
        {
            FrmDashboard frmdas = new FrmDashboard();
            frmdas.Show();
            this.Hide();
        }

        private void btnClearGM_Click(object sender, EventArgs e)
        {
            
        }

        private void btnUpdateGM_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteGM_Click(object sender, EventArgs e)
        { 
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM tblGM";
            SqlCommand com = new SqlCommand(sql, con);


            //Access data using data reader
            SqlDataReader dr = com.ExecuteReader();  // dr used to point"s the towards the data
            dr.Read();


            //Bind data will contrals
            this.txtcid.Text = dr.GetValue(0).ToString();
            this.txtName.Text = dr.GetValue(1).ToString();
            this.txtAge.Text = dr.GetValue(2).ToString();
            this.txtAddress.Text = dr.GetValue(3).ToString();
            this.txtContact.Text = dr.GetValue(4).ToString();


            


            //disconnect from Server
            con.Close();

        }


        private void LoadDAP_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM tblGM ORDER BY cid ASC";
            SqlCommand com = new SqlCommand(sql, con);


            //Access data using data reader
            SqlDataAdapter dap = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            dap.Fill(ds);
 

            this.dataGridView1.DataSource = ds.Tables[0];
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;


            //disconnect from Server
            con.Close();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            //connection
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();


            //command
            string sql = "UPDATE tblGM SET cid=@cid,cname=@cname,cage=@cage,caddress=@caddress,ccontact=@ccontact WHERE cid=@cid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@cid", this.txtcid.Text);
            com.Parameters.AddWithValue("@cname", this.txtName.Text);
            com.Parameters.AddWithValue("@cage", this.txtAge.Text);
            com.Parameters.AddWithValue("@caddress", this.txtAddress.Text);
            com.Parameters.AddWithValue("@ccontact", this.txtContact.Text);


            //Execute command to insert data
            int ret = com.ExecuteNonQuery();
            MessageBox.Show("No of Records Updated:" + ret, "Information");

            //disconect
            con.Close();

            //call to load button click
            LoadDAP_Click(sender, e);


            this.txtcid.Clear();
            this.txtName.Clear();
            this.txtAge.Clear();
            this.txtAddress.Clear();
            this.txtContact.Clear();

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

            

        }

        private void btnsave_Click(object sender, EventArgs e)
        {

            // fields are empty
            if (string.IsNullOrWhiteSpace(txtcid.Text) ||
                string.IsNullOrWhiteSpace(txtName.Text) ||
                string.IsNullOrWhiteSpace(txtAge.Text) ||
                string.IsNullOrWhiteSpace(txtAddress.Text) ||
                string.IsNullOrWhiteSpace(txtContact.Text))
                
            {
                MessageBox.Show("Please fill all the blanks", "Error");
                

            }
            else
            {



                //connection
                string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
                SqlConnection con = new SqlConnection(str);
                con.Open();


                //command
                string sql = "INSERT INTO tblGM(cid,cname,cage,caddress,ccontact) VALUES (@cid,@cname,@cage,@caddress,@ccontact)";
                SqlCommand com = new SqlCommand(sql, con);
                com.Parameters.AddWithValue("@cid", this.txtcid.Text);
                com.Parameters.AddWithValue("@cname", this.txtName.Text);
                com.Parameters.AddWithValue("@cage", this.txtAge.Text);
                com.Parameters.AddWithValue("@caddress", this.txtAddress.Text);
                com.Parameters.AddWithValue("@ccontact", this.txtContact.Text);


                //Execute command to insert data
                int ret = com.ExecuteNonQuery();
                MessageBox.Show("No of Records Inserted:" + ret, "Information");

                //disconect
                con.Close();

                this.txtName.Clear();
                this.txtAge.Clear();
                this.txtAddress.Clear();
                this.txtcid.Clear();
                this.txtContact.Clear();

                //call to load button click
                LoadDAP_Click(sender, e);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //connection
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();


            //command
            string sql = "DELETE FROM tblGM WHERE cid=@cid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@cid", this.txtcid.Text);
            com.Parameters.AddWithValue("@cname", this.txtName.Text);
            com.Parameters.AddWithValue("@cage", this.txtAge.Text);
            com.Parameters.AddWithValue("@caddress", this.txtAddress.Text);
            com.Parameters.AddWithValue("@ccntact", this.txtContact.Text);


            //Execute command to DElete data
            string msgret = MessageBox.Show("Are you sure you want to delete?", "Warning",
            MessageBoxButtons.YesNo, MessageBoxIcon.Warning).ToString();

            if (msgret == "Yes")
            {
                int ret = com.ExecuteNonQuery();
                MessageBox.Show("No of Records Deleted:" + ret, "Information");
            }
            //disconect
            con.Close();

            //call to load button click
            LoadDAP_Click(sender, e);

            this.txtName.Clear();
            this.txtAge.Clear();
            this.txtAddress.Clear();
            this.txtcid.Clear();
            this.txtContact.Clear();


        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM tblGM WHERE cid=@cid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@cid", this.txtcid.Text);


            //Access data using data reader
            SqlDataReader dr = com.ExecuteReader();  // dr used to point"s the towards the data

            if (dr.Read() == true)
            {


                //Bind data will contrals

                this.txtcid.Text = dr.GetValue(0).ToString();
                this.txtName.Text = dr.GetValue(1).ToString();
                this.txtAge.Text = dr.GetValue(2).ToString();
                this.txtAddress.Text = dr.GetValue(3).ToString();
                this.txtContact.Text = dr.GetValue(4).ToString();

            }
            else
            {
                MessageBox.Show("No records found");             
                
                this.txtName.Clear();
                this.txtAge.Clear();
                this.txtAddress.Clear();
                this.txtcid.Clear();
                this.txtContact.Clear();



            }


            //disconnect from Server
            con.Close();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            FrmBM frmBM = new FrmBM();
            frmBM.Show();
            this.Hide();
        }

        private void txtAge_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
