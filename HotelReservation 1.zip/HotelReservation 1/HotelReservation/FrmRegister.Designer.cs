﻿namespace HotelReservation
{
    partial class FrmRegister
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.txtFnameR = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtLnameR = new System.Windows.Forms.TextBox();
            this.btnClearR = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cbAccestype = new System.Windows.Forms.ComboBox();
            this.dtpR = new System.Windows.Forms.DateTimePicker();
            this.txtPasswordR = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtCpasswordR = new System.Windows.Forms.TextBox();
            this.btnBackR = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUsernameR = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(216, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(161, 29);
            this.label5.TabIndex = 96;
            this.label5.Text = "Date Of Birth :";
            // 
            // btnRegister
            // 
            this.btnRegister.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnRegister.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegister.Location = new System.Drawing.Point(730, 523);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(174, 34);
            this.btnRegister.TabIndex = 95;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = false;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(218, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 29);
            this.label3.TabIndex = 92;
            this.label3.Text = "First Name :";
            // 
            // txtFnameR
            // 
            this.txtFnameR.Location = new System.Drawing.Point(582, 96);
            this.txtFnameR.Name = "txtFnameR";
            this.txtFnameR.Size = new System.Drawing.Size(234, 22);
            this.txtFnameR.TabIndex = 91;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(71, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 36);
            this.label1.TabIndex = 36;
            this.label1.Text = "Register";
            // 
            // txtLnameR
            // 
            this.txtLnameR.Location = new System.Drawing.Point(582, 159);
            this.txtLnameR.Name = "txtLnameR";
            this.txtLnameR.Size = new System.Drawing.Size(234, 22);
            this.txtLnameR.TabIndex = 87;
            // 
            // btnClearR
            // 
            this.btnClearR.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnClearR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearR.Location = new System.Drawing.Point(429, 523);
            this.btnClearR.Name = "btnClearR";
            this.btnClearR.Size = new System.Drawing.Size(174, 34);
            this.btnClearR.TabIndex = 86;
            this.btnClearR.Text = "Clear";
            this.btnClearR.UseVisualStyleBackColor = false;
            this.btnClearR.Click += new System.EventHandler(this.btnClearR_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(218, 152);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 29);
            this.label2.TabIndex = 84;
            this.label2.Text = "Last Name :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(216, 438);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(163, 29);
            this.label6.TabIndex = 98;
            this.label6.Text = "Access Type :";
            // 
            // cbAccestype
            // 
            this.cbAccestype.FormattingEnabled = true;
            this.cbAccestype.Items.AddRange(new object[] {
            "Manager",
            "Staff"});
            this.cbAccestype.Location = new System.Drawing.Point(582, 445);
            this.cbAccestype.Name = "cbAccestype";
            this.cbAccestype.Size = new System.Drawing.Size(234, 24);
            this.cbAccestype.TabIndex = 99;
            // 
            // dtpR
            // 
            this.dtpR.Location = new System.Drawing.Point(582, 263);
            this.dtpR.Name = "dtpR";
            this.dtpR.Size = new System.Drawing.Size(234, 22);
            this.dtpR.TabIndex = 100;
            // 
            // txtPasswordR
            // 
            this.txtPasswordR.Location = new System.Drawing.Point(582, 323);
            this.txtPasswordR.Name = "txtPasswordR";
            this.txtPasswordR.Size = new System.Drawing.Size(234, 22);
            this.txtPasswordR.TabIndex = 102;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(218, 316);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 29);
            this.label4.TabIndex = 101;
            this.label4.Text = "Password :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(216, 380);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(222, 29);
            this.label7.TabIndex = 103;
            this.label7.Text = "Confirm Password :";
            // 
            // txtCpasswordR
            // 
            this.txtCpasswordR.Location = new System.Drawing.Point(582, 387);
            this.txtCpasswordR.Name = "txtCpasswordR";
            this.txtCpasswordR.Size = new System.Drawing.Size(234, 22);
            this.txtCpasswordR.TabIndex = 104;
            // 
            // btnBackR
            // 
            this.btnBackR.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnBackR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackR.Location = new System.Drawing.Point(120, 523);
            this.btnBackR.Name = "btnBackR";
            this.btnBackR.Size = new System.Drawing.Size(174, 34);
            this.btnBackR.TabIndex = 105;
            this.btnBackR.Text = "Back";
            this.btnBackR.UseVisualStyleBackColor = false;
            this.btnBackR.Click += new System.EventHandler(this.btnBackR_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(221, 205);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(136, 29);
            this.label8.TabIndex = 106;
            this.label8.Text = "Username :";
            // 
            // txtUsernameR
            // 
            this.txtUsernameR.Location = new System.Drawing.Point(582, 205);
            this.txtUsernameR.Name = "txtUsernameR";
            this.txtUsernameR.Size = new System.Drawing.Size(234, 22);
            this.txtUsernameR.TabIndex = 107;
            // 
            // FrmRegister
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HotelReservation.Properties.Resources.BaackgroundGold;
            this.ClientSize = new System.Drawing.Size(1174, 650);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtUsernameR);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.btnBackR);
            this.Controls.Add(this.txtCpasswordR);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtPasswordR);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpR);
            this.Controls.Add(this.cbAccestype);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtFnameR);
            this.Controls.Add(this.txtLnameR);
            this.Controls.Add(this.btnClearR);
            this.Controls.Add(this.label2);
            this.Name = "FrmRegister";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FrmRegister";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFnameR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtLnameR;
        private System.Windows.Forms.Button btnClearR;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbAccestype;
        private System.Windows.Forms.DateTimePicker dtpR;
        private System.Windows.Forms.TextBox txtPasswordR;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtCpasswordR;
        private System.Windows.Forms.Button btnBackR;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtUsernameR;
    }
}