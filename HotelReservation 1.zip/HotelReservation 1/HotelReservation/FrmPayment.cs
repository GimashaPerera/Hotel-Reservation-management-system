﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class FrmPayment : Form
    {
        public FrmPayment()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnBackP_Click(object sender, EventArgs e)
        {
            FrmDashboard frmdash = new FrmDashboard();
            frmdash.Show();
            this.Hide();
        }

        private void btnSearchP_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT rid, payment FROM tblBM1 WHERE rid=@rid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@rid", this.txtsearchP.Text);


            SqlDataAdapter dap = new SqlDataAdapter(com);
            DataTable ds = new DataTable();
            dap.Fill(ds);


            dgvPayments.DataSource = ds;

            // resize
            dgvPayments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            //disconnect from Server
            con.Close();
        }

        private void btnUpdateP_Click(object sender, EventArgs e)
        {
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();

                foreach (DataGridViewRow row in dgvPayments.Rows)
                {
                    if (row.IsNewRow) continue; // Skip the last row in the grid

                    int rid = Convert.ToInt32(row.Cells["rid"].Value);
                    decimal payment = Convert.ToDecimal(row.Cells["payment"].Value);

                    string sql = "UPDATE tblBM1 SET payment = @payment WHERE rid = @rid";
                    SqlCommand cmd = new SqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@payment", payment);
                    cmd.Parameters.AddWithValue("@rid", rid);

                    cmd.ExecuteNonQuery();
                }
                con.Close();
           
        }

        private void btnSaveP_Click(object sender, EventArgs e)
        {

        }

        private void btnDeleteP_Click(object sender, EventArgs e)
        {
            if (dgvPayments.SelectedRows.Count > 0) // Check if a row is selected
            {
                // Show confirmation dialog
                DialogResult result = MessageBox.Show("Are you sure you want to delete this record?",
                                                      "Confirm Delete",
                                                      MessageBoxButtons.YesNo,
                                                      MessageBoxIcon.Warning);

                if (result == DialogResult.Yes)
                {
                    int rid = Convert.ToInt32(dgvPayments.SelectedRows[0].Cells["rid"].Value); // Get rid from selected row

                    string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
                    using (SqlConnection con = new SqlConnection(str))
                    {
                        con.Open();

                        string sql = "DELETE FROM tblBM1 WHERE rid = @rid";
                        SqlCommand cmd = new SqlCommand(sql, con);
                        cmd.Parameters.AddWithValue("@rid", rid);
                        cmd.ExecuteNonQuery();
                    }

                    // Remove row from grid
                    dgvPayments.Rows.RemoveAt(dgvPayments.SelectedRows[0].Index);

                    MessageBox.Show("Deleted successfully!");
                }
            }
            else
            {
                MessageBox.Show("Please select a row to delete.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();

            string sql = "SELECT rid, payment FROM tblBM1"; // Load all records
            SqlCommand com = new SqlCommand(sql, con);

            SqlDataAdapter dap = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            dap.Fill(dt);

            dgvPayments.DataSource = dt; // Bind to DataGridView
            dgvPayments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; // Optional: Fit columns nicely

        }
    }
}

