﻿namespace HotelReservation
{
    partial class FrmEM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBackEM = new System.Windows.Forms.Button();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.lblNic = new System.Windows.Forms.Label();
            this.btnDeleteEM = new System.Windows.Forms.Button();
            this.btnEditEM = new System.Windows.Forms.Button();
            this.btnAddEM = new System.Windows.Forms.Button();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.txtNic = new System.Windows.Forms.TextBox();
            this.lblName = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.lblContact = new System.Windows.Forms.Label();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.lblEid = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txteid = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBackEM
            // 
            this.btnBackEM.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnBackEM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBackEM.Location = new System.Drawing.Point(35, 560);
            this.btnBackEM.Name = "btnBackEM";
            this.btnBackEM.Size = new System.Drawing.Size(128, 46);
            this.btnBackEM.TabIndex = 81;
            this.btnBackEM.Text = "Back";
            this.btnBackEM.UseVisualStyleBackColor = false;
            this.btnBackEM.Click += new System.EventHandler(this.btnBackEM_Click);
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(287, 389);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(200, 22);
            this.txtAddress.TabIndex = 80;
            // 
            // lblNic
            // 
            this.lblNic.AutoSize = true;
            this.lblNic.BackColor = System.Drawing.Color.Transparent;
            this.lblNic.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNic.ForeColor = System.Drawing.Color.White;
            this.lblNic.Location = new System.Drawing.Point(81, 330);
            this.lblNic.Name = "lblNic";
            this.lblNic.Size = new System.Drawing.Size(66, 29);
            this.lblNic.TabIndex = 79;
            this.lblNic.Text = "NIC :";
            // 
            // btnDeleteEM
            // 
            this.btnDeleteEM.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnDeleteEM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteEM.Location = new System.Drawing.Point(1002, 499);
            this.btnDeleteEM.Name = "btnDeleteEM";
            this.btnDeleteEM.Size = new System.Drawing.Size(125, 47);
            this.btnDeleteEM.TabIndex = 77;
            this.btnDeleteEM.Text = "Delete";
            this.btnDeleteEM.UseVisualStyleBackColor = false;
            this.btnDeleteEM.Click += new System.EventHandler(this.btnDeleteEM_Click);
            // 
            // btnEditEM
            // 
            this.btnEditEM.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnEditEM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditEM.Location = new System.Drawing.Point(625, 498);
            this.btnEditEM.Name = "btnEditEM";
            this.btnEditEM.Size = new System.Drawing.Size(178, 47);
            this.btnEditEM.TabIndex = 76;
            this.btnEditEM.Text = "All Employees";
            this.btnEditEM.UseVisualStyleBackColor = false;
            this.btnEditEM.Click += new System.EventHandler(this.btnEditEM_Click);
            // 
            // btnAddEM
            // 
            this.btnAddEM.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnAddEM.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddEM.Location = new System.Drawing.Point(391, 500);
            this.btnAddEM.Name = "btnAddEM";
            this.btnAddEM.Size = new System.Drawing.Size(122, 46);
            this.btnAddEM.TabIndex = 75;
            this.btnAddEM.Text = "Save";
            this.btnAddEM.UseVisualStyleBackColor = false;
            this.btnAddEM.Click += new System.EventHandler(this.btnAddEM_Click);
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(287, 449);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(200, 22);
            this.txtContact.TabIndex = 74;
            // 
            // txtNic
            // 
            this.txtNic.Location = new System.Drawing.Point(287, 330);
            this.txtNic.Name = "txtNic";
            this.txtNic.Size = new System.Drawing.Size(200, 22);
            this.txtNic.TabIndex = 73;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.ForeColor = System.Drawing.Color.White;
            this.lblName.Location = new System.Drawing.Point(81, 205);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(90, 29);
            this.lblName.TabIndex = 72;
            this.lblName.Text = "Name :";
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(287, 212);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(200, 22);
            this.txtName.TabIndex = 71;
            // 
            // lblContact
            // 
            this.lblContact.AutoSize = true;
            this.lblContact.BackColor = System.Drawing.Color.Transparent;
            this.lblContact.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContact.ForeColor = System.Drawing.Color.White;
            this.lblContact.Location = new System.Drawing.Point(81, 449);
            this.lblContact.Name = "lblContact";
            this.lblContact.Size = new System.Drawing.Size(144, 29);
            this.lblContact.TabIndex = 70;
            this.lblContact.Text = "Contact No :";
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(287, 273);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(200, 22);
            this.txtAge.TabIndex = 67;
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.BackColor = System.Drawing.Color.Transparent;
            this.lblAddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddress.ForeColor = System.Drawing.Color.White;
            this.lblAddress.Location = new System.Drawing.Point(81, 389);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(114, 29);
            this.lblAddress.TabIndex = 65;
            this.lblAddress.Text = "Address :";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.BackColor = System.Drawing.Color.Transparent;
            this.lblAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAge.ForeColor = System.Drawing.Color.White;
            this.lblAge.Location = new System.Drawing.Point(81, 273);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(68, 29);
            this.lblAge.TabIndex = 64;
            this.lblAge.Text = "Age :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(553, 23);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(595, 411);
            this.dataGridView1.TabIndex = 63;
            // 
            // lblEid
            // 
            this.lblEid.AutoSize = true;
            this.lblEid.BackColor = System.Drawing.Color.Transparent;
            this.lblEid.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEid.ForeColor = System.Drawing.Color.White;
            this.lblEid.Location = new System.Drawing.Point(23, 55);
            this.lblEid.Name = "lblEid";
            this.lblEid.Size = new System.Drawing.Size(163, 29);
            this.lblEid.TabIndex = 83;
            this.lblEid.Text = "Employee ID :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(126, 500);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(122, 46);
            this.button1.TabIndex = 85;
            this.button1.Text = "Update";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnSearch
            // 
            this.btnSearch.ForeColor = System.Drawing.Color.Black;
            this.btnSearch.Location = new System.Drawing.Point(260, 103);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(132, 47);
            this.btnSearch.TabIndex = 71;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // txteid
            // 
            this.txteid.Location = new System.Drawing.Point(227, 54);
            this.txteid.Name = "txteid";
            this.txteid.Size = new System.Drawing.Size(207, 30);
            this.txteid.TabIndex = 54;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txteid);
            this.groupBox1.Controls.Add(this.btnSearch);
            this.groupBox1.Controls.Add(this.lblEid);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(21, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(485, 169);
            this.groupBox1.TabIndex = 87;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Employee Details";
            // 
            // FrmEM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HotelReservation.Properties.Resources.BaackgroundGold;
            this.ClientSize = new System.Drawing.Size(1174, 650);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnBackEM);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.lblNic);
            this.Controls.Add(this.btnDeleteEM);
            this.Controls.Add(this.btnEditEM);
            this.Controls.Add(this.btnAddEM);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.txtNic);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.lblContact);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.lblAge);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FrmEM";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee Management";
            this.Load += new System.EventHandler(this.FrmEM_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBackEM;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label lblNic;
        private System.Windows.Forms.Button btnDeleteEM;
        private System.Windows.Forms.Button btnEditEM;
        private System.Windows.Forms.Button btnAddEM;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.TextBox txtNic;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.Label lblContact;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label lblEid;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txteid;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}