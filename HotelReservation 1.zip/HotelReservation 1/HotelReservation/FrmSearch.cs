﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class FrmSearch : Form
    {
        public FrmSearch()
        {
            InitializeComponent();
        }

        private void btnBackS_Click(object sender, EventArgs e)
        {
            FrmDashboard frmdash = new FrmDashboard();
            frmdash.Show();
            this.Hide();
        }

        private void btnSearchS_Click(object sender, EventArgs e)
        {
            //create a connection with ms sql server

            string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
            SqlConnection con = new SqlConnection(str);  //create connecion object
            con.Open();


            //Command to perform SQL Operations
            string sql = "SELECT * FROM tblBM1 WHERE rid=@rid";
            SqlCommand com = new SqlCommand(sql, con);
            com.Parameters.AddWithValue("@rid", this.txtSearchS.Text);


            //Access data using data reader
            SqlDataReader dr = com.ExecuteReader();  // dr used to point"s the towards the data

            if (dr.Read() == true)
            {


                //Bind data will contrals

                this.lblRidS.Text = dr.GetValue(0).ToString();
                this.lblrt.Text = dr.GetValue(1).ToString();
                this.lblcin.Text = dr.GetValue(2).ToString();
                this.lblcout.Text = dr.GetValue(3).ToString();
                this.lblpayment.Text = dr.GetValue(4).ToString();
               

            }
            else
            {
                MessageBox.Show("No records found");
            }


            //disconnect from Server
            con.Close();
        }

        private void lblRidS_Click(object sender, EventArgs e)
        {

        }

        private void txtSearchS_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
