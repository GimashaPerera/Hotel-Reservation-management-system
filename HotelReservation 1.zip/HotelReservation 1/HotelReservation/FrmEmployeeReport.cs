﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class frmEmployeeReport : Form
    {
        public frmEmployeeReport()
        {
            InitializeComponent();
        }

        private void frmEmployeeReport_Load(object sender, EventArgs e)
        {
            this.crystalReportViewer1.ReportSource = "C:\\Users\\Gimasha\\source\\repos\\HotelReservation 1\\HotelReservation\\HotelReservation\\CrystalReport1.rpt";
        }

        private void btnBackP_Click(object sender, EventArgs e)
        {
            FrmDashboard frmDash = new FrmDashboard();
            frmDash.Show();
            this.Hide();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
