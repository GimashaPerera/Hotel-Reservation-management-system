﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class frmCustomerReport : Form
    {
        public frmCustomerReport()
        {
            InitializeComponent();
        }

        private void btnBackP_Click(object sender, EventArgs e)
        {
            FrmDashboard frmDash = new FrmDashboard();
            frmDash.Show();
            this.Hide();
        }

        private void frmCustomerReport_Load(object sender, EventArgs e)
        {
            this.crystalReportViewer1.ReportSource = "C:\\Users\\Gimasha\\source\\repos\\HotelReservation 1\\HotelReservation\\HotelReservation\\CrystalReport2.rpt";
        }
        
    }
}
