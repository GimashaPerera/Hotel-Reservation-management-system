﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class FrmDashboard : Form
    { 

        string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";

       
        public FrmDashboard()
        {
            InitializeComponent();
            
        }

        private int GetReservationCount()
        {
            int count = 0;

            using (SqlConnection con = new SqlConnection(str))
            {
                string sql = "SELECT COUNT(*) FROM tblBM1";
                SqlCommand cmd = new SqlCommand(sql, con);

                try
                {
                    con.Open();
                    count =(int)cmd.ExecuteScalar();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error :" + ex.Message);
                }
            }
            return count;
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void contactNoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void btnLogoutD_Click(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();
        }

        private void btnEmployee_Click(object sender, EventArgs e)
        {
            FrmEMpass frmEMpass = new FrmEMpass();
            frmEMpass.Show();
            this.Close();
        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            FrmPayment frmPayment = new FrmPayment();
            frmPayment.Show();
            this.Hide();
        }

        private void btnSearchres_Click(object sender, EventArgs e)
        {
            FrmSearch frmSearch = new FrmSearch();
            frmSearch.Show();
            this.Hide();
        }

        private void viewProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();
        }

        private void roomPricesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPrices frmPrices = new FrmPrices();
            frmPrices.Show();
            this.Hide();
        }

        private void btnBooking_Click(object sender, EventArgs e)
        {
            FrmGM frmGM = new FrmGM();
            frmGM.Show();
            this.Hide();
        }

        private void btnGuestHandle_Click(object sender, EventArgs e)
        {

        }

        private void lblName_Click(object sender, EventArgs e)
        {
            
        }

        private void FrmDashboard_Load(object sender, EventArgs e)
        {
            
            lblName.Text = "Hi, " + Program.Username;  // Username display welcome


            int RC = GetReservationCount();
            lblOngoing.Text ="" + RC.ToString();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void employeeReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEmployeeReport FER = new frmEmployeeReport();
            FER.Show();
            this.Hide();
        }

        private void guestReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCustomerReport FCR = new frmCustomerReport();
            FCR.Show();
            this.Hide();
        }

        private void reserveReportToolStripMenuItem_Click(object sender, EventArgs e)
        {

            frmReservationReport FRR = new frmReservationReport();
            FRR.Show();
            this.Hide();
        }

        private void lblOngoing_Click(object sender, EventArgs e)
        {

        }
    }
}
