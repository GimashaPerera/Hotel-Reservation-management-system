﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelReservation
{
    public partial class FrmRegister : Form
    {
        public FrmRegister()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            // fields are empty
            if (string.IsNullOrWhiteSpace(txtFnameR.Text) ||
                string.IsNullOrWhiteSpace(txtLnameR.Text) ||
                string.IsNullOrWhiteSpace(txtUsernameR.Text) ||
                string.IsNullOrWhiteSpace(txtPasswordR.Text) ||
                string.IsNullOrWhiteSpace(txtCpasswordR.Text) ||
                string.IsNullOrWhiteSpace(cbAccestype.Text))
            {
                MessageBox.Show("Please fill all the blanks", "Error");
                return;
               
            }

            // Check passwords match
            if (txtPasswordR.Text != txtCpasswordR.Text)
            {
                MessageBox.Show("Passwords do not match", "Error");
                return;

            }
            else
            {


                // Connection String
                string str = "Data Source =DESKTOP-ISH42M9;initial Catalog=Hotel Reservation;Integrated Security=True";
                SqlConnection conn = new SqlConnection(str);
                conn.Open();

                string query = "INSERT INTO tblRegister (FirstName, LastName, Username, Password, Cpassword, DateofBirth, AccessType) " +
                               "VALUES (@Firstname, @Lastname, @Username, @Password, @Cpassword, @dtpr, @accesstype)";
                SqlCommand com = new SqlCommand(query, conn);

                com.Parameters.AddWithValue("@Firstname", txtFnameR.Text);
                com.Parameters.AddWithValue("@Lastname", txtLnameR.Text);
                com.Parameters.AddWithValue("@Username", txtUsernameR.Text);
                com.Parameters.AddWithValue("@Password", txtPasswordR.Text);
                com.Parameters.AddWithValue("@Cpassword", txtCpasswordR.Text);
                com.Parameters.AddWithValue("@dtpr", dtpR.Value);
                com.Parameters.AddWithValue("@accesstype", cbAccestype.Text);

                com.ExecuteNonQuery();



                MessageBox.Show("Successfully Registered! Please login again.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                FrmLogin frmlogin = new FrmLogin();
                frmlogin.Show();
                this.Hide();
            }
        }

        private void btnBackR_Click(object sender, EventArgs e)
        {
            FrmLogin frmlogin = new FrmLogin();
            frmlogin.Show();
            this.Hide();
        }

        private void btnClearR_Click(object sender, EventArgs e)
        {
            txtFnameR.Clear();
            txtLnameR.Clear();
            txtUsernameR.Clear();
            txtPasswordR.Clear();
            txtCpasswordR.Clear();
            cbAccestype.SelectedIndex = -1;
            dtpR.Value = DateTime.Now;
        }
    }
}
